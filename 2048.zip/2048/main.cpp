#include "Display.h"

int main() {
    Display display;
    display.run();

}